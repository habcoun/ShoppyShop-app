import 'package:get/get.dart';

class NewsController extends GetxController {}
