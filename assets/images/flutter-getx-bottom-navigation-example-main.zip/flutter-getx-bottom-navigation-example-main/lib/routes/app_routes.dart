class AppRoutes {
  static const String DASHBOARD = '/';
}
